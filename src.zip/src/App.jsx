import React, { useState, useEffect, Children } from 'react';
import './App.scss';
import ConfluenceComponent from './components/Confluence';

function App() {
  return (
    <>
      <ConfluenceComponent />;
    </>
  );
}

export default App;
