import React, { useEffect, useState } from 'react';
import { fetchData } from '../utils/store';
import '../App.scss';

function ConfluenceComponent({ elementId = 1 }) {
  const [data, setData] = useState([]);

  useEffect(async () => {
    fetchData().then((res) => {
      setData(res);
    });
  }, []);

  return (
    <div>
      <div className="container">
        {data?.map((response) => {
          return (
            <>
              <ParentComp response={response} elementId={elementId} />
            </>
          );
        })}
      </div>
    </div>
  );
}

const ParentComp = ({
  response,
  marginLeft = 0,
  elementId = { elementId },
}) => {
  const [isHide, setIsHide] = useState(false);

  const isFolder = response.children;

  return (
    <div>
      <div
        className="wrappper"
        onClick={() => {
          setIsHide(!isHide);
        }}
      >
        {isFolder ? '#' : '.'}
        <div style={{ marginLeft: `${marginLeft}px`, TextAligh: 'left' }}>
          {response.name}
        </div>
      </div>

      {isHide &&
        elementId === response.id &&
        response?.children?.map((childRes, index) => {
          return (
            <ParentComp
              response={childRes}
              key={index}
              marginLeft={marginLeft + 100}
              isCollapsed={isHide}
            />
          );
        })}
    </div>
  );
};

export default ConfluenceComponent;
